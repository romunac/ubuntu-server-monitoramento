#!/bin/bash
echo MONITORAMENTO
